$(function () {

  'use strict';

  var $distpicker = $('#distpicker');


 
  $('#distpicker2').distpicker({
    province: '---- 所在省 ----',
    city: '---- 所在市 ----',
    district: '---- 所在区 ----'
  });

 

});
