function getattr(obj,attr){
    return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj)[attr]
}
var shop = $('.shop');
var left = $('.left');
var all = $('.all');
var sum = document.getElementById('sum');


//单选
for(var i=0; i<left.length; i++){
    left[i].onclick = function(){
        var iparent = this.parentNode.parentNode;

        var le = iparent.getElementsByClassName('left');

        if(getattr($(this).find('i')[0],'display') == 'none'){

            $(this).find('i')[0].style.display = 'block';

        }else{
            $(this).find('i')[0].style.display = 'none';

        };
        if(iif(le)){

            iparent.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'block';

        }else{
            $('#footer i').css('display','none');
            iparent.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'none';

        };
        screen();
    };
};

// 店铺全选
for(var j=0; j<all.length; j++){
    all[j].onclick = function(){
        var iparent = this.parentNode.parentNode;
        for(var i=0; i<iparent.getElementsByClassName('left').length; i++){

            if(getattr($(this).find('i')[0],'display') == 'none'){

                iparent.getElementsByClassName('left')[i].getElementsByTagName('i')[0].style.display = 'block';
                if(iparent.getElementsByTagName('input')[i].value == 0){
                    iparent.getElementsByTagName('input')[i].value = 1;
                }
            }else{
                iparent.getElementsByClassName('left')[i].getElementsByTagName('i')[0].style.display = 'none';
                $('#footer i').css('display','none');
            }
        }

        if(getattr($(this).find('i')[0],'display') == 'none'){
            this.getElementsByTagName('i')[0].style.display = 'block'
        }else{
            this.getElementsByTagName('i')[0].style.display = 'none'
        }
        screen()
    }
}

//加减
var l = document.getElementById('wrap').getElementsByClassName('border-left'); // 加
var r = document.getElementById('wrap').getElementsByClassName('border-right'); //减

for(var j=0; j<r.length; j++){

    l[j].onclick = function(){  //加加加加
        var p = this.parentNode.parentNode.parentNode.parentNode.parentNode;

        var le = p.parentNode.getElementsByClassName('left');

        if(iif(le)){
            p.parentNode.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'block';
        }else{
            p.parentNode.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'none';
        };
        this.parentNode.getElementsByTagName('input')[0].value++;

        screen()

    }

    r[j].onclick = function(){   // 减减减减减减减减减减减减
        var p = this.parentNode.parentNode.parentNode.parentNode.parentNode;

        var le = p.parentNode.getElementsByClassName('left');

        if(iif(le)){
            p.parentNode.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'block';

        }else{
            p.parentNode.getElementsByClassName('all')[0].getElementsByTagName('i')[0].style.display = 'none';

        };

        this.parentNode.getElementsByTagName('input')[0].value--;

        if(this.parentNode.getElementsByTagName('input')[0].value <= 1){
            this.parentNode.getElementsByTagName('input')[0].value = 1;
            alert('受不了了，宝贝不能再减少了哦~')
        }
        screen()
    }


}

// 删除
var com = $('#com');
var pary = $('.pary');
var remove = $('.com');
var Ainput = $('.input');
var arr = [];
var p =[];
for(var j=0; j<pary.length; j++){
    arr.push(pary[j].innerHTML);
    p.push(Ainput[j].parentNode);
    remove[j].onclick = function(){
        var p = this.parentNode.parentNode.parentNode;
        lage(p,{height:0},function(){
            p.innerHTML = '';
            p.className = '';
            screen();
            if( parseInt(getattr(p.parentNode,'height')) < 60){
                lage(p.parentNode,{height:0},function(){
                    p.parentNode.innerHTML = '';
                })
            }
        })

    }

}


//编辑
var on = true;
com[0].onclick = function(){
    for(var i=0; i<remove.length; i++){
        if(on){
            pary[i].innerHTML = '';
            pary[i].appendChild(Ainput[i]);
            Ainput[i].style.float = 'left';
            lage(remove[i],{right:0});
            this.innerHTML = '完成';
        }else{
            pary[i].innerHTML = '';
            pary[i].innerHTML = arr[i];
            this.innerHTML = '编辑';
            p[i].appendChild(Ainput[i]);
            Ainput[i].style.float = 'right';
            lage(remove[i],{right:-50});
        }
    }
    on = !on
}

//全选
$('#footer span').click(function(){
    var len = document.getElementsByTagName('input').length;
    var ilen = document.getElementsByTagName('i').length;

    if($('#footer i').css('display') == 'block'){
        $('#footer i').css('display','none');

        for(var i=0; i<len; i++){

            document.getElementsByTagName('i')[i].style.display = 'none';
        };
        for(var j=0; j<ilen; j++){
            document.getElementsByTagName('i')[j].style.display = 'none';
        };


    }else{
        for(var i=0; i<len; i++){
        };

        for(var j=0; j<ilen; j++){
            document.getElementsByTagName('i')[j].style.display = 'block';
        }


        $('#footer i').css('display','block')

    };
    screen();
});


function screen(){
    var box = document.getElementById('wrap').getElementsByClassName('box')
    var le = document.getElementById('wrap').getElementsByClassName('left')
    var n = 0
    for(var i=0; i<le.length; i++){

        if(getattr(le[i].getElementsByTagName('i')[0],'display') == 'block'){
            n += box[i].getElementsByTagName('input')[0].value*(box[i].getElementsByClassName('color')[0].innerHTML+box[i].getElementsByClassName('color-2')[0].innerHTML)
        }

    }
    sum.innerHTML = parseFloat(n).toFixed(2)

}

function iif(obj){
    for(var i=0; i<obj.length; i++){
        if(getattr(obj[i].getElementsByTagName('i')[0],'display') == 'none'){
            return false;
        }
    }
    return true;
}

function lage(obj,json,fun){
    clearInterval(obj.time);
    obj.time = setInterval(function(){
        var onoff = true;
        for (var attr in json){
            var inew = parseInt(getattr(obj,attr))
            var isp = (json[attr]-inew)/3
            if(isp>0){
                isp = Math.ceil(isp) //向上去整
            }else{
                isp = Math.floor(isp) // 向下去整
            }
            if(inew == json[attr]){
                if(onoff){
                    clearInterval(obj.time)
                    fun && fun()
                }
            }else{
                onoff = false
                obj.style[attr] = inew+isp+'px'
            }
        }
    },100)
}
